import React, { Component, useState } from "react";
import Person from "./Persons/Person";
import CreatePersonButton from "./Persons/CreatePersonButton";
export const Dashboradtwo = () => {
  const [title, settitle] = useState("hello");
  const [persons, setpersons] = useState([
    {
      name: "dichen",
      descibe: "asda",
      
      
    
    },
    
  ]);

  return (
    <div className="Persons">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <h1 className="display-4 text-center">{title}</h1>
            <br />
            <CreatePersonButton />
            <CreatePersonButton hello={"created book"} />
            <button
              onClick={() => {
                settitle("Person")
                setpersons(persons)
 
                      
              }}
            >
              button
            </button>

            <br />
            {persons.map((person) => (
              <Person person={person}></Person>
            ))}

            <hr />
            {/*<Person /> */}
            {/* <Person halo={"personname"} /> */}
          </div>
        </div>
      </div>
    </div>
  );
};

class Dashborad extends Component {
  render() {
    return (
      <div className="Persons">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h1 className="display-4 text-center">Persons</h1>
              <br />
              <CreatePersonButton />
              <CreatePersonButton hello={"created book"} />

              <br />
              <hr />
              <Person />
              <Person haalo={"personname"} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Dashborad;
