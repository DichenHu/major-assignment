import React, { Component } from "react";

export const SideBar = () => {
    return (
        <div style={{
            border:"solid 1px",
            padding: 12
        }}>
            ModifyBook
            <br />
            Approve User
        </div>
    );
};
