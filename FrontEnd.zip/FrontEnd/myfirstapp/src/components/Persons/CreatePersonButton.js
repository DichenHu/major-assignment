import React from 'react'
import {link, Link} from "react-router-dom";

 const CreatePersonButton=({hello}) => {
    return (


        <React.Fragment>
        <Link to="/addPerson"
        className="btn btn-lg btn-info">
        {hello}
        
        </Link>
        </React.Fragment>
    )
};
export default CreatePersonButton;