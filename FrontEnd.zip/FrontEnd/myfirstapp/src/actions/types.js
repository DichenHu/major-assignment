export const GET_ERRORS = "GET_ERRORS";
export const GET_PERSONS = "GET_PERSONS";
export const GET_PERSON = "GET_PERSON";


export const SET_CURRENT_USER = "SET_CURRENT_USER";

